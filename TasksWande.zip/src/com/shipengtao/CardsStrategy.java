package com.shipengtao;

import com.sun.deploy.util.StringUtils;

import java.util.Map;

public abstract class CardsStrategy {

    abstract void strategy(Player player1, Player player2, Map<Player, Card> roundCards);

    void executeGroupStrategy (Player player1, Player player2, Map<Player, Card> roundCards,String strategy){

        if (strategy==null){

        }

    }
}
